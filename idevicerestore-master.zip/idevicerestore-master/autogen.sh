#!/bin/bash
aclocal
autoconf
automake
./configure
